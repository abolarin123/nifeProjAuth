<?php 
session_start();
if(isset($_SESSION['success'])){
    ?>
<div class="alert alert-primary alert-dismissible fade show" role="alert">
    <i class="fa fa-exclamation-circle me-2"></i><?php echo $_SESSION['success']; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

                            
    <?php
    unset($_SESSION['success']);
}
?>

<?php
if(isset($_SESSION['error'])){
    ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fa fa-exclamation-circle me-2"></i><?php echo $_SESSION['danger']; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

                            
    <?php
    unset($_SESSION['error']);
}
?>

<?php
if(isset($_SESSION['msg'])){
    ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <i class="fa fa-exclamation-circle me-2"></i><?php echo $_SESSION['msg']; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

                            
    <?php
    unset($_SESSION['msg']);
}
?>